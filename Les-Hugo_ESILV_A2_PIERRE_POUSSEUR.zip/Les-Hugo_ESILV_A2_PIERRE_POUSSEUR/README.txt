Avancement : 
- 03/02/HPR Structure du site et test javascript (canvas) pour le labyrinthe
- 03-02/HPE Ajout du README, reprise du dossier JS_tuto pour les pages, ajout des règles sur la page d'accueil
- 04/02/HPE Ajout de la page rank et des scores

--------------------

Récapitulatif : 
- TP1 : Création du site, des pages, de leurs structure, de la bannière. Commencement du javascript (canvas). Toutes les pages communiquent entre elles.